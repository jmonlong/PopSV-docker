+ Test more cancer functions: aneuploidy flag
+ Unit tests for the pv estimation in tumor situation
+ SV summary interactive:
    + Issue with frequency dictribution when thousands of sample and proportion view ?
    + Add mean coverage distribution in CNVs
