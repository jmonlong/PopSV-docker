library(testthat)
library(PopSV)

test_check("PopSV")
